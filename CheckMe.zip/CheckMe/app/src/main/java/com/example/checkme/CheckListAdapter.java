package com.example.checkme;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityOptionsCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CheckListAdapter extends RecyclerView.Adapter<CheckListViewHolder>{

        private List<CheckList> Checklists;
        public CheckListAdapter(List<CheckList> Checklists)
        {
            this.Checklists = Checklists;
        }

        @NonNull
        @Override
        public CheckListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v =LayoutInflater.from(parent.getContext()).inflate(R.layout.checklist,parent,false);
            CheckListViewHolder vh = new CheckListViewHolder(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull CheckListViewHolder holder, int position) {
            CheckList checkList = Checklists.get(position);

            holder.image.setImageResource(checkList.getImage());
            holder.name.setText(checkList.getName());
            holder.card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(v.getContext(),MainActivity2.class);
                    v.getContext().startActivity(i);
                }
            });
        }

        @Override
        public int getItemCount() {
            return Checklists.size();
        }
    }
