package com.example.checkme;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;



        public class PersonalizedItemAdapter extends RecyclerView.Adapter<PersonalizedItemViewHolder> {

        List<ItemPersonalized> items;

        public PersonalizedItemAdapter(){
            items = new ArrayList<>();
            items.add(new ItemPersonalized("Almond Milk"));
        }

        @NonNull
        @Override
        public PersonalizedItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_personalized_layout,parent,false);
            PersonalizedItemViewHolder vh = new PersonalizedItemViewHolder(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull PersonalizedItemViewHolder holder, int position) {
            ItemPersonalized item = items.get(position);
            holder.checkbox.setText(ItemPersonalized.getItem());

        }


        @Override
        public int getItemCount() {
            return items.size();
        }

        public void AddPersonalizedItem(ItemPersonalized item) {
            items.add(item);
            notifyDataSetChanged();
        }

        public void DeleteItem(int pos) {
            items.remove(pos);
            notifyDataSetChanged();
        }
    }

