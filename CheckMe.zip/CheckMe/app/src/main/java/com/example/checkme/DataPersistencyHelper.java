package com.example.checkme;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class DataPersistencyHelper {

        public static Context Context;

        public static void StoreData(List<CheckList> Checklists)
        {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(Context);
            SharedPreferences.Editor editor = sp.edit();
            String json = new Gson().toJson(Checklists);
            editor.putString("Checklists", json);
            editor.commit();
        }

        public static List<CheckList> LoadData()
        {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(Context);
            String json = sp.getString("Checklists",null);
            if (json != null)
            {
                Type type = new TypeToken<List<CheckList>>(){}.getType();
                return new Gson().fromJson(json,type);
            }
            else
            {
                List<CheckList> Checklists = new ArrayList<CheckList>();
                Checklists.add(new CheckList(R.drawable.party,"Party Checklist"));
                Checklists.add(new CheckList(R.drawable.pharmacy,"Pharmacy Checklist"));
                Checklists.add(new CheckList(R.drawable.shopping,"Essentials Checklist"));
                return Checklists;
            }
        }

    }

