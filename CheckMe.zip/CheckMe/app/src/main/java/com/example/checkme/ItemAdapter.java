package com.example.checkme;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

import androidx.recyclerview.widget.RecyclerView;

import com.example.checkme.MainActivity2;
import com.example.checkme.Item;
import com.example.checkme.R;


import java.util.List;



    public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

        private List<Item> items;
        private final MainActivity2 activity;


        public ItemAdapter(MainActivity2 activity){
            this.activity = activity;
        }

        public void onBindViewHolder(ViewHolder holder,int position){
            Item item = items.get(position);
            holder.item.setText(item.getName());
        }

        public int getItemCount(){
            return items.size();
        }
        private boolean toBoolean(int n){
            return n!=0;
        }

        public void setItems(List<Item> items){
            this.items = items;
            notifyDataSetChanged();

        }

        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.party_layout,parent, false);
            return new ViewHolder(itemView);
        }
        public static class ViewHolder extends RecyclerView.ViewHolder{
            CheckBox item;

            ViewHolder(View view) {
                super(view);
                item = view.findViewById(R.id.tobuyCheckBox);
            }

        }
    }

